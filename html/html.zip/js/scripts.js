$( document ).ready( function() {

    /*------------------------------*/
    /*----------Main Slider---------*/ 
    /*------------------------------*/
    $( "#main-slider" ).owlCarousel( {
        navigation : true,
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem : true,
        autoPlay : true
    } );

    /*------------------------------*/
    /*----------navbar-toggle-------*/ 
    /*------------------------------*/
    transformicons.add('.tcon');

} );